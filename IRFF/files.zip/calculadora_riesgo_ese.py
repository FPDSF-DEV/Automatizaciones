#!/usr/bin/env python3
"""
Calculadora de Riesgo para Empresas Sociales del Estado (ESE)
Basado en la Resolución 2509 de 2012 del Ministerio de Salud y Protección Social

Este script calcula la categorización de riesgo de las ESE usando datos del SIHO
(Sistema de Información Hospitalario)
"""

import json
from datetime import datetime
from typing import Dict, Tuple


class CalculadoraRiesgoESE:
    """
    Calcula el índice de riesgo de una ESE según la metodología establecida
    en la Resolución 2509 de 2012
    """
    
    # Porcentajes para proyección de recaudo según nivel de atención
    PORCENTAJES_RECAUDO = {
        1: {  # Nivel 1
            'corto_plazo': 0.80,  # 80% cartera < 90 días
            'largo_plazo_medio': 0.70,  # 70% cartera 90-360 días
            'largo_plazo_largo': 0.50   # 50% cartera > 360 días
        },
        2: {  # Nivel 2
            'corto_plazo': 0.80,  # 80% cartera < 180 días
            'largo_plazo_medio': 0.75,  # 75% cartera 180-360 días
            'largo_plazo_largo': 0.50   # 50% cartera > 360 días
        },
        3: {  # Nivel 3
            'corto_plazo': 0.80,  # 80% cartera < 180 días
            'largo_plazo_medio': 0.75,  # 75% cartera 180-360 días
            'largo_plazo_largo': 0.50   # 50% cartera > 360 días
        }
    }
    
    # Categorías de riesgo
    CATEGORIAS_RIESGO = [
        {'nombre': 'SIN RIESGO', 'min': 0.00, 'max': float('inf')},
        {'nombre': 'RIESGO BAJO', 'min': -0.10, 'max': -0.01},
        {'nombre': 'RIESGO MEDIO', 'min': -0.20, 'max': -0.11},
        {'nombre': 'RIESGO ALTO', 'min': float('-inf'), 'max': -0.21}
    ]
    
    def __init__(self):
        self.datos = {}
        self.resultados = {}
        
    def solicitar_datos_basicos(self):
        """Solicita información básica de la ESE"""
        print("\n" + "="*70)
        print("CALCULADORA DE RIESGO PARA EMPRESAS SOCIALES DEL ESTADO")
        print("Resolución 2509 de 2012")
        print("="*70)
        
        self.datos['nombre_ese'] = input("\nNombre de la ESE: ").strip()
        self.datos['municipio'] = input("Municipio: ").strip()
        self.datos['departamento'] = input("Departamento: ").strip()
        
        while True:
            try:
                nivel = int(input("Nivel de atención (1, 2 o 3): "))
                if nivel in [1, 2, 3]:
                    self.datos['nivel_atencion'] = nivel
                    break
                else:
                    print("Error: El nivel debe ser 1, 2 o 3")
            except ValueError:
                print("Error: Ingrese un número válido")
        
        # Pregunta sobre condiciones especiales de mercado
        print("\n--- CONDICIONES ESPECIALES DE MERCADO ---")
        print("¿La ESE opera en condiciones de mercado especiales?")
        print("(Quintil más alto de dispersión poblacional Y única opción para urgencias/partos)")
        print("O (Servicios de internación exclusivos para salud mental)")
        
        mercado_especial = input("¿Condiciones especiales? (S/N): ").strip().upper()
        self.datos['mercado_especial'] = mercado_especial == 'S'
        
    def solicitar_ingresos_operacionales(self):
        """
        Solicita datos de ingresos operacionales del SIHO
        
        DÓNDE ENCONTRAR EN EL SIHO:
        - Módulo: Ejecución Presupuestal de Ingresos
        - Reporte: Ingresos Recaudados por Concepto
        - Período: Vigencia fiscal correspondiente (01/01 - 31/12)
        """
        print("\n" + "="*70)
        print("INGRESOS OPERACIONALES CORRIENTES RECAUDADOS")
        print("="*70)
        print("\nDÓNDE OBTENER ESTOS DATOS EN EL SIHO:")
        print("• Módulo: Ejecución Presupuestal de Ingresos")
        print("• Reporte: Ingresos Recaudados")
        print("• Filtro: Ingresos Operacionales - Vigencia actual")
        print("• Corte: 31 de diciembre de la vigencia anterior")
        print("-"*70)
        
        self.datos['ingresos_venta_servicios'] = self._solicitar_valor(
            "Ingresos por venta de servicios de salud (recaudados)"
        )
        
        self.datos['otros_ingresos_corrientes'] = self._solicitar_valor(
            "Otros ingresos corrientes (recaudados)"
        )
        
        if self.datos['mercado_especial']:
            self.datos['aportes_no_ligados'] = self._solicitar_valor(
                "Aportes no ligados a ventas de servicios (recaudados)"
            )
        else:
            self.datos['aportes_no_ligados'] = 0
            
    def solicitar_cartera(self):
        """
        Solicita datos de cartera del SIHO
        
        DÓNDE ENCONTRAR EN EL SIHO:
        - Módulo: Cartera
        - Reporte: Antigüedad de Cartera / Aging de Cartera
        - Clasificación por días de antigüedad
        """
        print("\n" + "="*70)
        print("CARTERA RADICADA (CUENTAS POR COBRAR)")
        print("="*70)
        print("\nDÓNDE OBTENER ESTOS DATOS EN EL SIHO:")
        print("• Módulo: Cartera / Cuentas por Cobrar")
        print("• Reporte: Antigüedad de Cartera (Aging)")
        print("• Clasificación: Por rangos de días")
        print("• Corte: 31 de diciembre de la vigencia anterior")
        print("-"*70)
        
        nivel = self.datos['nivel_atencion']
        
        if nivel == 1:
            print("\nNIVEL 1 - Clasificación de cartera:")
            print("• Cartera de CORTO PLAZO: Menor a 90 días")
            print("• Cartera de LARGO PLAZO: 90 días o más")
            print()
            
            self.datos['cartera_menor_90'] = self._solicitar_valor(
                "Cartera menor a 90 días"
            )
            self.datos['cartera_90_360'] = self._solicitar_valor(
                "Cartera entre 90 y 360 días"
            )
            self.datos['cartera_mayor_360'] = self._solicitar_valor(
                "Cartera mayor a 360 días"
            )
            
        else:  # Nivel 2 o 3
            print(f"\nNIVEL {nivel} - Clasificación de cartera:")
            print("• Cartera de CORTO PLAZO: Menor a 180 días")
            print("• Cartera de LARGO PLAZO: 180 días o más")
            print()
            
            self.datos['cartera_menor_180'] = self._solicitar_valor(
                "Cartera menor a 180 días"
            )
            self.datos['cartera_180_360'] = self._solicitar_valor(
                "Cartera entre 180 y 360 días"
            )
            self.datos['cartera_mayor_360'] = self._solicitar_valor(
                "Cartera mayor a 360 días"
            )
    
    def solicitar_gastos_operacionales(self):
        """
        Solicita datos de gastos operacionales del SIHO
        
        DÓNDE ENCONTRAR EN EL SIHO:
        - Módulo: Ejecución Presupuestal de Gastos
        - Reporte: Gastos Comprometidos
        """
        print("\n" + "="*70)
        print("GASTOS OPERACIONALES CORRIENTES COMPROMETIDOS")
        print("="*70)
        print("\nDÓNDE OBTENER ESTOS DATOS EN EL SIHO:")
        print("• Módulo: Ejecución Presupuestal de Gastos")
        print("• Reporte: Gastos Comprometidos")
        print("• Clasificación: Gastos de Funcionamiento + Gastos de Operación")
        print("• Corte: 31 de diciembre de la vigencia anterior")
        print("-"*70)
        
        self.datos['gastos_funcionamiento'] = self._solicitar_valor(
            "Gastos de funcionamiento (comprometidos)"
        )
        
        self.datos['gastos_operacion'] = self._solicitar_valor(
            "Gastos de operación comercial y prestación de servicios (comprometidos)"
        )
    
    def solicitar_pasivos(self):
        """
        Solicita datos de pasivos del SIHO
        
        DÓNDE ENCONTRAR EN EL SIHO:
        - Módulo: Contabilidad / Balance General
        - Reporte: Pasivos por Antigüedad
        """
        print("\n" + "="*70)
        print("PASIVOS CON ANTIGÜEDAD MAYOR A UN AÑO")
        print("="*70)
        print("\nDÓNDE OBTENER ESTOS DATOS EN EL SIHO:")
        print("• Módulo: Contabilidad - Balance General")
        print("• Reporte: Pasivos por Antigüedad")
        print("• Filtro: Pasivos adquiridos en vigencias anteriores (> 1 año)")
        print("• Corte: 31 de diciembre de la vigencia anterior")
        print("-"*70)
        
        self.datos['pasivos_mayores_1_anio'] = self._solicitar_valor(
            "Pasivos con edad superior a un año"
        )
    
    def solicitar_ejecucion_presupuestal(self):
        """
        Solicita datos de ejecución presupuestal total del SIHO
        
        DÓNDE ENCONTRAR EN EL SIHO:
        - Módulo: Presupuesto
        - Reporte: Ejecución Presupuestal Consolidada
        """
        print("\n" + "="*70)
        print("EJECUCIÓN PRESUPUESTAL DE LA VIGENCIA")
        print("="*70)
        print("\nDÓNDE OBTENER ESTOS DATOS EN EL SIHO:")
        print("• Módulo: Ejecución Presupuestal")
        print("• Reporte: Ejecución Presupuestal Consolidada")
        print("• Total de Ingresos Reconocidos vs Gastos Comprometidos")
        print("• Período: Vigencia completa (01/01 - 31/12)")
        print("-"*70)
        
        self.datos['ingresos_reconocidos_total'] = self._solicitar_valor(
            "Total de ingresos RECONOCIDOS (todos los conceptos)"
        )
        
        self.datos['gastos_comprometidos_total'] = self._solicitar_valor(
            "Total de gastos COMPROMETIDOS (todos los conceptos)"
        )
    
    def calcular_proyeccion_recaudo_corto_plazo(self) -> float:
        """Calcula la proyección de recaudo de cartera de corto plazo"""
        nivel = self.datos['nivel_atencion']
        porcentajes = self.PORCENTAJES_RECAUDO[nivel]
        
        if nivel == 1:
            # Nivel 1: 80% de cartera < 90 días
            proyeccion = self.datos['cartera_menor_90'] * porcentajes['corto_plazo']
        else:
            # Nivel 2 y 3: 80% de cartera < 180 días
            proyeccion = self.datos['cartera_menor_180'] * porcentajes['corto_plazo']
        
        return proyeccion
    
    def calcular_proyeccion_recaudo_largo_plazo(self) -> float:
        """Calcula la proyección de recaudo de cartera de largo plazo"""
        nivel = self.datos['nivel_atencion']
        porcentajes = self.PORCENTAJES_RECAUDO[nivel]
        
        if nivel == 1:
            # Nivel 1: 70% cartera 90-360 días + 50% cartera > 360 días
            proyeccion = (
                self.datos['cartera_90_360'] * porcentajes['largo_plazo_medio'] +
                self.datos['cartera_mayor_360'] * porcentajes['largo_plazo_largo']
            )
        else:
            # Nivel 2 y 3: 75% cartera 180-360 días + 50% cartera > 360 días
            proyeccion = (
                self.datos['cartera_180_360'] * porcentajes['largo_plazo_medio'] +
                self.datos['cartera_mayor_360'] * porcentajes['largo_plazo_largo']
            )
        
        return proyeccion
    
    def calcular_superavit_deficit_corriente(self) -> float:
        """Calcula el superávit o déficit de la operación corriente"""
        # Ingresos operacionales corrientes recaudados
        ingresos_corrientes = (
            self.datos['ingresos_venta_servicios'] +
            self.datos['otros_ingresos_corrientes'] +
            self.calcular_proyeccion_recaudo_corto_plazo()
        )
        
        # Para mercado especial, agregar aportes no ligados
        if self.datos['mercado_especial']:
            ingresos_corrientes += self.datos['aportes_no_ligados']
        
        # Gastos operacionales corrientes comprometidos
        gastos_corrientes = (
            self.datos['gastos_funcionamiento'] +
            self.datos['gastos_operacion']
        )
        
        superavit_deficit = ingresos_corrientes - gastos_corrientes
        
        # Guardar para el cálculo del índice
        self.resultados['ingresos_corrientes'] = ingresos_corrientes
        self.resultados['gastos_corrientes'] = gastos_corrientes
        
        return superavit_deficit
    
    def calcular_superavit_deficit_no_corriente(self) -> float:
        """Calcula el superávit o déficit de la operación no corriente"""
        proyeccion_recaudo_largo = self.calcular_proyeccion_recaudo_largo_plazo()
        pasivos = self.datos['pasivos_mayores_1_anio']
        
        superavit_deficit = proyeccion_recaudo_largo - pasivos
        
        # Guardar para referencia
        self.resultados['proyeccion_largo_plazo'] = proyeccion_recaudo_largo
        self.resultados['pasivos'] = pasivos
        
        return superavit_deficit
    
    def calcular_superavit_deficit_total(self) -> float:
        """Calcula el superávit o déficit total"""
        corriente = self.calcular_superavit_deficit_corriente()
        no_corriente = self.calcular_superavit_deficit_no_corriente()
        
        total = corriente + no_corriente
        
        self.resultados['superavit_deficit_corriente'] = corriente
        self.resultados['superavit_deficit_no_corriente'] = no_corriente
        self.resultados['superavit_deficit_total'] = total
        
        return total
    
    def calcular_ingresos_operacionales_totales(self) -> float:
        """Calcula los ingresos operacionales totales recaudados"""
        ingresos_totales = (
            self.datos['ingresos_venta_servicios'] +
            self.datos['otros_ingresos_corrientes'] +
            self.calcular_proyeccion_recaudo_corto_plazo() +
            self.calcular_proyeccion_recaudo_largo_plazo()
        )
        
        # Para mercado especial, agregar aportes no ligados
        if self.datos['mercado_especial']:
            ingresos_totales += self.datos['aportes_no_ligados']
        
        self.resultados['ingresos_operacionales_totales'] = ingresos_totales
        
        return ingresos_totales
    
    def calcular_indice_riesgo(self) -> float:
        """Calcula el índice de riesgo"""
        superavit_deficit_total = self.calcular_superavit_deficit_total()
        ingresos_totales = self.calcular_ingresos_operacionales_totales()
        
        if ingresos_totales == 0:
            print("\n⚠️  ADVERTENCIA: Los ingresos operacionales totales son cero.")
            print("No se puede calcular el índice de riesgo.")
            return float('-inf')
        
        indice = superavit_deficit_total / ingresos_totales
        self.resultados['indice_riesgo'] = indice
        
        return indice
    
    def calcular_superavit_deficit_presupuestal(self) -> float:
        """Calcula el superávit o déficit presupuestal"""
        superavit = (
            self.datos['ingresos_reconocidos_total'] -
            self.datos['gastos_comprometidos_total']
        )
        
        self.resultados['superavit_deficit_presupuestal'] = superavit
        
        return superavit
    
    def determinar_categoria_riesgo(self) -> str:
        """Determina la categoría de riesgo según los criterios establecidos"""
        indice = self.calcular_indice_riesgo()
        deficit_presupuestal = self.calcular_superavit_deficit_presupuestal() < 0
        
        # Criterio (e): Si hay déficit presupuestal, es riesgo alto
        if deficit_presupuestal:
            return 'RIESGO ALTO'
        
        # Determinar categoría por índice
        if indice >= 0.00:
            return 'SIN RIESGO'
        elif -0.10 <= indice <= -0.01:
            return 'RIESGO BAJO'
        elif -0.20 <= indice <= -0.11:
            return 'RIESGO MEDIO'
        else:  # indice <= -0.21
            return 'RIESGO ALTO'
    
    def generar_reporte(self):
        """Genera un reporte detallado de los resultados"""
        print("\n" + "="*70)
        print("REPORTE DE CATEGORIZACIÓN DE RIESGO")
        print("="*70)
        print(f"\nESE: {self.datos['nombre_ese']}")
        print(f"Municipio: {self.datos['municipio']}")
        print(f"Departamento: {self.datos['departamento']}")
        print(f"Nivel de atención: {self.datos['nivel_atencion']}")
        print(f"Condiciones especiales de mercado: {'Sí' if self.datos['mercado_especial'] else 'No'}")
        print(f"Fecha de cálculo: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        print("\n" + "-"*70)
        print("RESUMEN FINANCIERO")
        print("-"*70)
        
        print(f"\n1. INGRESOS OPERACIONALES CORRIENTES:")
        print(f"   Venta de servicios:        ${self.datos['ingresos_venta_servicios']:>20,.2f}")
        print(f"   Otros ingresos corrientes: ${self.datos['otros_ingresos_corrientes']:>20,.2f}")
        print(f"   Proyección cartera C.P.:   ${self.calcular_proyeccion_recaudo_corto_plazo():>20,.2f}")
        if self.datos['mercado_especial']:
            print(f"   Aportes no ligados:        ${self.datos['aportes_no_ligados']:>20,.2f}")
        print(f"   TOTAL INGRESOS CORRIENTES: ${self.resultados['ingresos_corrientes']:>20,.2f}")
        
        print(f"\n2. GASTOS OPERACIONALES CORRIENTES:")
        print(f"   Gastos de funcionamiento:  ${self.datos['gastos_funcionamiento']:>20,.2f}")
        print(f"   Gastos de operación:       ${self.datos['gastos_operacion']:>20,.2f}")
        print(f"   TOTAL GASTOS CORRIENTES:   ${self.resultados['gastos_corrientes']:>20,.2f}")
        
        print(f"\n3. SUPERÁVIT/DÉFICIT CORRIENTE:   ${self.resultados['superavit_deficit_corriente']:>20,.2f}")
        
        print(f"\n4. PROYECCIÓN RECAUDO LARGO PLAZO: ${self.resultados['proyeccion_largo_plazo']:>20,.2f}")
        print(f"   Pasivos > 1 año:           ${self.resultados['pasivos']:>20,.2f}")
        
        print(f"\n5. SUPERÁVIT/DÉFICIT NO CORRIENTE: ${self.resultados['superavit_deficit_no_corriente']:>20,.2f}")
        
        print(f"\n6. SUPERÁVIT/DÉFICIT TOTAL:        ${self.resultados['superavit_deficit_total']:>20,.2f}")
        
        print(f"\n7. INGRESOS OPERACIONALES TOTALES: ${self.resultados['ingresos_operacionales_totales']:>20,.2f}")
        
        print(f"\n8. ÍNDICE DE RIESGO:               {self.resultados['indice_riesgo']:>24.4f}")
        
        print(f"\n9. EJECUCIÓN PRESUPUESTAL:")
        print(f"   Ingresos reconocidos:      ${self.datos['ingresos_reconocidos_total']:>20,.2f}")
        print(f"   Gastos comprometidos:      ${self.datos['gastos_comprometidos_total']:>20,.2f}")
        print(f"   Superávit/Déficit:         ${self.resultados['superavit_deficit_presupuestal']:>20,.2f}")
        
        categoria = self.determinar_categoria_riesgo()
        
        print("\n" + "="*70)
        print(f"CATEGORIZACIÓN: {categoria}")
        print("="*70)
        
        # Interpretación
        print("\nINTERPRETACIÓN:")
        if categoria == 'SIN RIESGO':
            print("✓ La ESE NO presenta riesgo fiscal y financiero.")
            print("  No requiere adoptar Programa de Saneamiento Fiscal y Financiero.")
        elif categoria == 'RIESGO BAJO':
            print("⚠ La ESE presenta riesgo BAJO.")
            print("  No requiere adoptar Programa de Saneamiento Fiscal y Financiero.")
        elif categoria == 'RIESGO MEDIO':
            print("⚠ La ESE presenta riesgo MEDIO.")
            print("  DEBE adoptar Programa de Saneamiento Fiscal y Financiero")
            print("  en los 60 días siguientes a la comunicación oficial.")
        else:  # RIESGO ALTO
            print("⛔ La ESE presenta riesgo ALTO.")
            print("  DEBE adoptar Programa de Saneamiento Fiscal y Financiero")
            print("  en los 60 días siguientes a la comunicación oficial.")
            print("  La no adopción puede ser causal de intervención por parte")
            print("  de la Superintendencia Nacional de Salud.")
        
        return categoria
    
    def exportar_json(self, nombre_archivo: str = None):
        """Exporta los resultados a un archivo JSON"""
        if nombre_archivo is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            nombre_archivo = f"riesgo_ese_{timestamp}.json"
        
        datos_exportar = {
            'fecha_calculo': datetime.now().isoformat(),
            'datos_ese': self.datos,
            'resultados': self.resultados,
            'categoria_riesgo': self.determinar_categoria_riesgo()
        }
        
        with open(nombre_archivo, 'w', encoding='utf-8') as f:
            json.dump(datos_exportar, f, indent=2, ensure_ascii=False)
        
        print(f"\n✓ Resultados exportados a: {nombre_archivo}")
        
    def _solicitar_valor(self, concepto: str) -> float:
        """Solicita un valor numérico al usuario"""
        while True:
            try:
                valor_str = input(f"{concepto}: $").strip().replace(',', '').replace('.', '')
                valor = float(valor_str)
                if valor < 0:
                    print("Error: El valor no puede ser negativo")
                    continue
                return valor
            except ValueError:
                print("Error: Ingrese un valor numérico válido")


def main():
    """Función principal"""
    calculadora = CalculadoraRiesgoESE()
    
    try:
        # Recolectar datos
        calculadora.solicitar_datos_basicos()
        calculadora.solicitar_ingresos_operacionales()
        calculadora.solicitar_cartera()
        calculadora.solicitar_gastos_operacionales()
        calculadora.solicitar_pasivos()
        calculadora.solicitar_ejecucion_presupuestal()
        
        # Generar reporte
        categoria = calculadora.generar_reporte()
        
        # Preguntar si desea exportar
        exportar = input("\n¿Desea exportar los resultados a JSON? (S/N): ").strip().upper()
        if exportar == 'S':
            calculadora.exportar_json()
        
        print("\n" + "="*70)
        print("Cálculo completado exitosamente")
        print("="*70)
        
    except KeyboardInterrupt:
        print("\n\nProceso cancelado por el usuario")
    except Exception as e:
        print(f"\n⛔ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
